# 喻麒麟第三次作业部分

- 姓名：喻麒麟
- 学号：U202412699
- 小组仓库：https://github.com/P1ngye/summer_courses
- 负责模块：`area_calculator.py`

## 完成内容

1. 保留第一次作业的 `square_area`、`rectangle_area`、`triangle_area`、`circle_area` 和 `calculate_area` 接口，确保不影响组内调用。
2. 抽取统一的正数、有限数校验函数，消除重复代码。
3. 使用 `_AREA_RULES` 配置表替换重复的条件分支，增强可维护性和可扩展性。
4. 为模块、函数、参数、返回值和异常补充文档字符串，可由 Python `pydoc` 自动生成帮助页面。
5. 编写 13 项 `unittest` 单元测试，覆盖四个公式、统一分派、缺失参数以及异常数值。

## 测试方法

在本目录执行：

```powershell
python -m unittest -v test_area_calculator.py
```

生成本模块的自动 API 文档：

```powershell
python -m pydoc -w area_calculator
```

生成的 `area_calculator.html` 可交给组长并入全组 CHM 帮助文档。
