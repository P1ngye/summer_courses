"""通用面积计算器的面积计算模块。

负责人：喻麒麟（U202412699）

本模块只处理已经统一为厘米的尺寸，返回值单位为平方厘米。重构内容：

* 抽取统一的有限正数校验，删除四个公式中的重复校验代码；
* 使用配置表完成图形分派，新增图形时无需修改条件判断链；
* 计算过程保持原始精度，仅在展示层进行舍入；
* 保留第一次作业的全部公开函数，避免影响其他组员模块。
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from numbers import Real


def _positive_finite_number(value: Real, field_name: str) -> float:
    """把长度校验并转换为有限正浮点数。

    Args:
        value: 待校验的长度。
        field_name: 参数名，用于生成明确的错误提示。

    Returns:
        校验通过的浮点数。

    Raises:
        ValueError: 值不是数值、不是有限数或不大于零。
    """
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{field_name} must be a number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{field_name} must be finite")
    if number <= 0:
        raise ValueError(f"{field_name} must be greater than zero")
    return number


def square_area(side: Real) -> float:
    """计算正方形面积。

    Args:
        side: 边长，单位为厘米。

    Returns:
        正方形面积，单位为平方厘米。
    """
    side_cm = _positive_finite_number(side, "side")
    return side_cm**2


def rectangle_area(length: Real, width: Real) -> float:
    """根据长和宽计算长方形面积。"""
    length_cm = _positive_finite_number(length, "length")
    width_cm = _positive_finite_number(width, "width")
    return length_cm * width_cm


def triangle_area(base: Real, height: Real) -> float:
    """根据底和高计算三角形面积。"""
    base_cm = _positive_finite_number(base, "base")
    height_cm = _positive_finite_number(height, "height")
    return base_cm * height_cm / 2


def circle_area(diameter: Real) -> float:
    """根据直径计算圆形面积。"""
    diameter_cm = _positive_finite_number(diameter, "diameter")
    return math.pi * (diameter_cm / 2) ** 2


AreaFunction = Callable[..., float]

# 图形类型 ->（按调用顺序排列的必需字段、对应面积函数）
_AREA_RULES: dict[str, tuple[tuple[str, ...], AreaFunction]] = {
    "square": (("side",), square_area),
    "rectangle": (("length", "width"), rectangle_area),
    "triangle": (("base", "height"), triangle_area),
    "circle": (("diameter",), circle_area),
}


def calculate_area(shape_type: str, dimensions: Mapping[str, Real]) -> float:
    """按图形类型分派并计算面积。

    Args:
        shape_type: ``square``、``rectangle``、``triangle`` 或 ``circle``。
        dimensions: 以参数名为键、厘米长度为值的映射。

    Returns:
        未舍入的面积，单位为平方厘米。

    Raises:
        ValueError: 图形类型未知、尺寸不是映射、字段缺失或值不合法。
    """
    if shape_type not in _AREA_RULES:
        supported = ", ".join(_AREA_RULES)
        raise ValueError(
            f"unsupported shape type: {shape_type!r}; supported types: {supported}"
        )
    if not isinstance(dimensions, Mapping):
        raise ValueError("dimensions must be a mapping")

    required_fields, area_function = _AREA_RULES[shape_type]
    missing_fields = [field for field in required_fields if field not in dimensions]
    if missing_fields:
        missing = ", ".join(missing_fields)
        raise ValueError(f"missing required dimensions for {shape_type}: {missing}")

    return area_function(*(dimensions[field] for field in required_fields))


def supported_shapes() -> tuple[str, ...]:
    """返回当前支持的图形类型，供界面或文档使用。"""
    return tuple(_AREA_RULES)
