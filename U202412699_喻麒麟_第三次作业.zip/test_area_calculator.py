"""喻麒麟负责的 area_calculator 模块单元测试。"""

import math
import unittest

from area_calculator import (
    calculate_area,
    circle_area,
    rectangle_area,
    square_area,
    supported_shapes,
    triangle_area,
)


class AreaFormulaTests(unittest.TestCase):
    """逐个验证四个最小面积公式单元。"""

    def test_square_area(self) -> None:
        self.assertEqual(square_area(2), 4.0)

    def test_rectangle_area(self) -> None:
        self.assertEqual(rectangle_area(3, 4), 12.0)

    def test_triangle_area(self) -> None:
        self.assertEqual(triangle_area(6, 4), 12.0)

    def test_circle_uses_diameter(self) -> None:
        self.assertAlmostEqual(circle_area(2), math.pi)

    def test_decimal_input_keeps_precision(self) -> None:
        self.assertAlmostEqual(rectangle_area(2.5, 3.2), 8.0)


class AreaDispatcherTests(unittest.TestCase):
    """验证统一分派接口的正常与异常路径。"""

    def test_dispatches_every_supported_shape(self) -> None:
        cases = (
            ("square", {"side": 2}, 4.0),
            ("rectangle", {"length": 3, "width": 4}, 12.0),
            ("triangle", {"base": 6, "height": 4}, 12.0),
            ("circle", {"diameter": 2}, math.pi),
        )
        for shape_type, dimensions, expected in cases:
            with self.subTest(shape_type=shape_type):
                self.assertAlmostEqual(calculate_area(shape_type, dimensions), expected)

    def test_supported_shape_order_is_stable(self) -> None:
        self.assertEqual(
            supported_shapes(),
            ("square", "rectangle", "triangle", "circle"),
        )

    def test_rejects_unknown_shape(self) -> None:
        with self.assertRaisesRegex(ValueError, "unsupported shape type"):
            calculate_area("hexagon", {"side": 2})

    def test_rejects_non_mapping_dimensions(self) -> None:
        with self.assertRaisesRegex(ValueError, "must be a mapping"):
            calculate_area("square", [2])

    def test_reports_each_missing_dimension(self) -> None:
        with self.assertRaisesRegex(ValueError, "length, width"):
            calculate_area("rectangle", {})


class AreaValidationTests(unittest.TestCase):
    """验证公共接口能够拒绝危险或无意义的尺寸。"""

    def test_rejects_zero_and_negative_values(self) -> None:
        for value in (0, -1, -0.5):
            with self.subTest(value=value), self.assertRaisesRegex(
                ValueError, "greater than zero"
            ):
                calculate_area("square", {"side": value})

    def test_rejects_non_finite_values(self) -> None:
        for value in (math.inf, -math.inf, math.nan):
            with self.subTest(value=value), self.assertRaisesRegex(
                ValueError, "finite"
            ):
                calculate_area("circle", {"diameter": value})

    def test_rejects_non_numeric_values_and_bool(self) -> None:
        for value in ("2", True, None):
            with self.subTest(value=value), self.assertRaisesRegex(
                ValueError, "must be a number"
            ):
                calculate_area("triangle", {"base": value, "height": 3})


if __name__ == "__main__":
    unittest.main(verbosity=2)
